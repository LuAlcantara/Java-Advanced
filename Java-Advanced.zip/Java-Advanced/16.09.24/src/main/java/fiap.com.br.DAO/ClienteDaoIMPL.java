package fiap.com.br.DAO;

import javax.persistence.EntityManager;

import fiap.com.br.ENTITY.Cliente;
import fiap.com.br.EXCEPTION.CommitException;
import fiap.com.br.EXCEPTION.IdNaoEncontradoException;

public class ClienteDaoIMPL {
    private EntityManager em;
    public ClienteDaoIMPL(EntityManager em) {
        this.em = em;
    }

    public void cadastrar(Cliente cliente) {
        em.persist(cliente);
    }

    public void atualizar(Cliente cliente) throws IdNaoEncontradoException {
        buscarPorId(cliente.getId()); //valida se existe o cliente para atualizar
        em.merge(cliente);
    }
    public void remover(int id) throws IdNaoEncontradoException {
        Cliente cliente = buscarPorId(id);
        em.remove(cliente);
    }
    public Cliente buscarPorId(int id) throws IdNaoEncontradoException {
        Cliente cliente = em.find(Cliente.class, id);
        if(cliente == null)
            throw new IdNaoEncontradoException("Cliente não encontrado");
        return cliente;
    }
    public void commit () throws CommitException {
        try {
            em.getTransaction().begin();
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
            em.getTransaction().rollback();
            throw new CommitException();
        }
    }
}
