package fiap.com.br.DAO;

import fiap.com.br.entity.Cliente;
import fiap.com.br.exception.CommitException;
import fiap.com.br.exception.IdNaoEncontradoException;

public interface ClienteDao {
    void cadastrar(Cliente cliente);
    void atualizar(Cliente cliente);
    void remover(Cliente cliente) throws IdNaoEncontradoException;
    void remover(int id) throws IdNaoEncontradoException;
    Cliente buscarPorId(int id) throws IdNaoEncontradoException;
    void commit() throws CommitException;
}
