package br.com.fiap.beans;

public class Funcionario {
    public String nome;
    pu
}
