package br.com.fiap.beans;

public class VelhoImovel extends imoveis {
    public void DescontoImovel (String endereco, double preco) {
        super (endereco, preco);
    }
}
