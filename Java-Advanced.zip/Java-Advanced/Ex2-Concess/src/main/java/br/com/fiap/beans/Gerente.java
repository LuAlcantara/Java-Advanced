package br.com.fiap.beans;

public class Gerente extends Funcionario {
    public void calcSalario() {
        this.salario = 6000;
    }
}
