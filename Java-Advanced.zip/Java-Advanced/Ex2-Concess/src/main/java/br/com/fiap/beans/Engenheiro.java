package br.com.fiap.beans;

public class Engenheiro extends Funcionario{
    public void calcSalario(){

        this.salario = 5000;
    }
}
