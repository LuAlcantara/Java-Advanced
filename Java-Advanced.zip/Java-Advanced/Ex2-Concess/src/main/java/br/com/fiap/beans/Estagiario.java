package br.com.fiap.beans;

public class Estagiario extends Funcionario{
    public void calcSalario(){
    this.salario = 800;
}
}
