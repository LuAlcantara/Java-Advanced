package br.com.fiap.beans;

public class Analista extends Funcionario{
    public void calcSalario(){

        this.salario = 3000;
    }
}
